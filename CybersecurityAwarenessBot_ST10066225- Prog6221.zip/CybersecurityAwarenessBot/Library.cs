using System;

namespace CybersecurityAwarenessBot
{
    // Contains helper methods used across the project
    internal static class Library
    {
        public static void DisplayDivider()
        {
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine(new string('-', 50)); // Simple horizontal line
            Console.ResetColor();
        }
    }
}