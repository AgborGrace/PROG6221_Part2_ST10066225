using System;
using System.Threading;

namespace CybersecurityAwarenessBot
{
    // Provides utility methods for enhancing user experience
    internal static class Utils
    {
        public static void TypingEffect(string message)
        {
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(30); // Typing simulation delay
            }
            Console.WriteLine();
        }
    }
}