# Cybersecurity Awareness Bot

This is a simple command-line chatbot built in C# to raise awareness about cybersecurity topics like password safety, phishing, and safe browsing.

## Features
- ASCII art header
- Voice greeting (`welcome.wav`)
- Predefined responses for common questions
- Enhanced UI with colors and structure
- GitHub CI integration

## Requirements
- .NET 5 SDK
- WAV file at `files/welcome.wav`

## Run
```bash
dotnet build
dotnet run
```