using System;
using System.Drawing;

namespace CybersecurityAwarenessBot
{
    // Converts and displays an image as ASCII art in the console
    internal class ImageDisplay
    {
        public void Show()
        {
            string imagePath = "files/chatbot.png"; // Path to the chatbot image
            int width = 60;
            int height = 30;

            Console.OutputEncoding = System.Text.Encoding.UTF8;
            ConvertImageToAscii(imagePath, width, height);
        }

        private void ConvertImageToAscii(string imagePath, int newWidth, int newHeight)
        {
            Bitmap image = new Bitmap(imagePath);
            image = new Bitmap(image, new Size(newWidth, newHeight));

            string asciiChars = "@%#*+=-:. "; // Ordered by brightness

            for (int y = 0; y < image.Height; y++)
            {
                for (int x = 0; x < image.Width; x++)
                {
                    Color pixelColor = image.GetPixel(x, y);
                    int grayValue = (pixelColor.R + pixelColor.G + pixelColor.B) / 3;
                    int index = grayValue * (asciiChars.Length - 1) / 255;
                    Console.Write(asciiChars[index]);
                }
                Console.WriteLine();
            }
        }
    }
}