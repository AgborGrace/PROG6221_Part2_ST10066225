using System;
using System.Collections.Generic;

namespace CybersecurityAwarenessBot
{
    // Stores and returns predefined chatbot responses for known inputs
    internal static class ChatBotData
    {
        private static readonly Dictionary<string, string> Responses = new Dictionary<string, string>()
        {
            { "how are you", "I'm doing great! Ready to help you stay safe online!" },
            { "what's your purpose", "I'm here to raise awareness about cybersecurity practices." },
            { "what can i ask you about", "Ask me about password safety, phishing, or safe browsing!" },
            { "password safety", "Use long, unique passwords and a password manager if possible." },
            { "phishing", "Avoid clicking on suspicious links or opening unknown attachments." },
            { "safe browsing", "Stick to HTTPS websites and be cautious with downloads." }
        };

        public static string GetResponse(string input)
        {
            input = input.ToLower().Trim();
            return Responses.ContainsKey(input) ? Responses[input] : "I didn’t quite understand that. Could you rephrase?";
        }
    }
}