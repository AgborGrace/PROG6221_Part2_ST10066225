using System;

namespace CybersecurityAwarenessBot
{
    // Responsible for displaying the menu options to the user
    internal static class MenuDisplay
    {
        public static void ShowMenu(string userName)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Library.DisplayDivider();
            Console.WriteLine($"Hi {userName}, how can I assist you today?");
            Library.DisplayDivider();
            Console.ResetColor();

            Console.WriteLine("You can ask me about:");
            Console.WriteLine(" - Password safety");
            Console.WriteLine(" - Phishing");
            Console.WriteLine(" - Safe browsing");
            Console.WriteLine("Or try general questions like 'How are you?'");
        }
    }
}