using System;
using System.Media;

namespace CybersecurityAwarenessBot
{
    // Responsible for playing a welcome audio file at the start of the chatbot session
    internal class AudioPlayer
    {
        public void Play()
        {
            string filePath = "files/welcome_audio.wav"; // Path to the audio file
            using (SoundPlayer player = new SoundPlayer(filePath))
            {
                player.PlaySync(); // Play synchronously so greeting finishes before proceeding
            }
        }
    }
}