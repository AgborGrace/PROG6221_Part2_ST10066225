using System;
using System.Drawing;

namespace ChatBotCyberSecurity
{
    /// <summary>
    /// Handles the display of images as ASCII art in the console
    /// </summary>
    internal class ImageDisplay
    {
        /// <summary>
        /// Shows the chatbot image as ASCII art in the console
        /// </summary>
        public void Show()
        {
            // Path to the chatbot image file - update if needed
            string imagePath = "files/ChatBot.png";

            // Width and height for the ASCII representation
            // Adjust these values based on your console size and image details
            int width = 60;
            int height = 30;

            // Set console to support UTF-8 characters
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Convert and display the image
            ConvertImageToAscii(imagePath, width, height);
        }

        /// <summary>
        /// Converts an image to ASCII art and displays it in the console
        /// </summary>
        /// <param name="imagePath">Path to the image file</param>
        /// <param name="newWidth">Desired width of the ASCII output</param>
        /// <param name="newHeight">Desired height of the ASCII output</param>
        private void ConvertImageToAscii(string imagePath, int newWidth, int newHeight)
        {
            try
            {
                // Load the image from file
                Bitmap image = new Bitmap(imagePath);

                // Resize the image to our target dimensions
                image = new Bitmap(image, new Size(newWidth, newHeight));

                // ASCII characters ordered by brightness (darkest to lightest)
                // You can customize this string to change the appearance
                string asciiChars = "@%#*+=-:. ";

                // Process each pixel row by row
                for (int y = 0; y < image.Height; y++)
                {
                    for (int x = 0; x < image.Width; x++)
                    {
                        // Get pixel color at current position
                        Color pixelColor = image.GetPixel(x, y);

                        // Convert RGB to grayscale using average method
                        int grayValue = (pixelColor.R + pixelColor.G + pixelColor.B) / 3;

                        // Map grayscale value to an ASCII character
                        int index = grayValue * (asciiChars.Length - 1) / 255;

                        // Write the corresponding ASCII character
                        Console.Write(asciiChars[index]);
                    }
                    // Move to the next line after each row is complete
                    Console.WriteLine();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error displaying image: {ex.Message}");
            }
        }
    }
}
