﻿using System;
using System.Media;

namespace CybersecurityAwarenessBot
{
    // This class is responsible for playing the welcome audio message.
    internal class AudioPlayer
    {
        public void Play()
        {
            // Path to the audio file — ensure the file is named exactly 'Welcome.wav'
            string filePath = "files/Welcome.wav";

            try
            {
                // Create a SoundPlayer to load and play the audio
                using (SoundPlayer player = new SoundPlayer(filePath))
                {
                    player.PlaySync(); // Play audio synchronously (waits for it to finish)
                }
            }
            catch (Exception ex)
            {
                // Display an error message if the audio file is not found or can't be played
                Console.WriteLine("Error: Could not play the welcome audio.");
                Console.WriteLine("Details: " + ex.Message);
            }
        }
    }
}
