using System;
using ChatBotCyberSecurity;

namespace CybersecurityAwarenessBot
{
    // Main program entry point
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Cybersecurity Awareness Bot";

            AudioPlayer audioPlayer = new AudioPlayer();
            audioPlayer.Play();

            ImageDisplay imageDisplay = new ImageDisplay();
            imageDisplay.Show();

            Utils.TypingEffect("Welcome to the Cybersecurity Awareness Bot!");

            Console.Write("\nPlease enter your name: ");
            string userName = Console.ReadLine();

            Console.Clear();
            imageDisplay.Show();
            Utils.TypingEffect($"Hello {userName}, I'm your friendly cybersecurity assistant.");

            while (true)
            {
                MenuDisplay.ShowMenu(userName);

                Console.Write("\nYou: ");
                string input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input)) continue;

                string response = ChatBotData.GetResponse(input);
                Utils.TypingEffect("Bot: " + response);

                Console.WriteLine("\nWould you like to ask another question? (yes/no)");
                string again = Console.ReadLine().ToLower();
                if (again != "yes") break;

                Console.Clear();
            }

            Console.WriteLine("Goodbye and stay safe online!");
        }
    }
}